package com.library.service;

import com.library.repository.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BookService {

    private BookRepository bookRepository;

    // Constructor for constructor injection
    @Autowired
    public BookService(BookRepository bookRepository) {
        System.out.println("constructor is invoked");
        this.bookRepository = bookRepository;
    }

    // Setter for setter injection (optional, in case you need it)
    @Autowired
    public void setBookRepository(BookRepository bookRepository) {
        System.out.println("Setter is called");
        this.bookRepository = bookRepository;
    }

    public void listBooks() {
        System.out.println("Listing books from the repository...");
        // Use bookRepository to perform operations
    }
}
