package com.library.repository;

import org.springframework.stereotype.Repository;

@Repository
public class BookRepository {

    public void getBooks() {
        // Implementation for retrieving books
        System.out.println("Retrieving books from the repository...");
    }
}
